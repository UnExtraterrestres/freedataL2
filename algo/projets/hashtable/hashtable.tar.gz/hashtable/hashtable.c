#include "hashtable.h"

#include <assert.h>
#include <stdlib.h>
#include <string.h>

/*
 * value
 */

enum value_kind value_get_kind(const struct value *self) {
  return VALUE_NIL;
}

bool value_is_nil(const struct value *self) {
  return true;
}

bool value_is_boolean(const struct value *self) {
  return true;
}

bool value_is_integer(const struct value *self) {
  return true;
}

bool value_is_real(const struct value *self) {
  return true;
}

bool value_is_custom(const struct value *self) {
  return true;
}


void value_set_nil(struct value *self) {
}

void value_set_boolean(struct value *self, bool val) {
}

void value_set_integer(struct value *self, int64_t val) {
}

void value_set_real(struct value *self, double val) {
}

void value_set_custom(struct value *self, void *val) {
}


bool value_get_boolean(const struct value *self) {
  return true;
}

int64_t value_get_integer(const struct value *self) {
  return 0;
}

double value_get_real(const struct value *self) {
  return 0.0;
}

void *value_get_custom(const struct value *self) {
  return NULL;
}


struct value value_make_nil() {
  struct value res;
  return res;
}

struct value value_make_boolean(bool val) {
  struct value res;
  return res;
}

struct value value_make_integer(int64_t val) {
  struct value res;
  return res;
}

struct value value_make_real(double val) {
  struct value res;
  return res;
}

struct value value_make_custom(void *val) {
  struct value res;
  return res;
}



/*
 * hashtable
 */

void hashtable_create(struct hashtable *self) {
}

void hashtable_destroy(struct hashtable *self) {
}

size_t hashtable_get_count(const struct hashtable *self) {
  return 0;
}

size_t hashtable_get_size(const struct hashtable *self) {
  return 0;
}


bool hashtable_insert(struct hashtable *self, const char *key, struct value value) {
  return true;
}

bool hashtable_remove(struct hashtable *self, const char *key) {
  return false;
}


bool hashtable_contains(const struct hashtable *self, const char *key) {
  return true;
}

void hashtable_rehash(struct hashtable *self) {
}

void hashtable_set_nil(struct hashtable *self, const char *key) {
}

void hashtable_set_boolean(struct hashtable *self, const char *key, bool val) {
}

void hashtable_set_integer(struct hashtable *self, const char *key, int64_t val) {
}

void hashtable_set_real(struct hashtable *self, const char *key, double val) {
}

void hashtable_set_custom(struct hashtable *self, const char *key, void *val) {
}

struct value hashtable_get(struct hashtable *self, const char *key) {
  struct value res;
  return res;
}
