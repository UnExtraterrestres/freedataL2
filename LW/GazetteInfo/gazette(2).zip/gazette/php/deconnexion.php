<?php

require_once 'bibli_gazette.php';

// démarrage ou reprise de la session
// pas besoin de démarrer la bufferisation des sorties
session_start();

sessionExit();
