#include <stdio.h>
#include <stdlib.h>

#include "bits/movie.h"

int main(){
  struct movie m;
  movie_create(&m, "Matrix Resurrections", 22, 12, 2021);
  movie_print(&m);
  movie_destroy(&m);

  return 0;
}
