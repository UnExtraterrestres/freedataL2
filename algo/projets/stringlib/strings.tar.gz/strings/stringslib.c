#include "stringslib.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

size_t str_length(const char *str) {
  return 0;
}

int str_compare(const char *str1, const char *str2) {
  return 0;
}

const char *str_search(const char *needle, const char *haystack) {
  return NULL;
}


const char *str_search_first_char(char needle, const char *haystack) {
  return NULL;
}

const char *str_search_last_char(char needle, const char *haystack) {
  return NULL;
}


size_t str_prefix_accept(const char *str, const char *chars) {
  return 0;
}

size_t str_prefix_reject(const char *str, const char *chars) {
  return 0;
}

int str_to_integer(const char *str) {
  return 0;
}


int str_to_integer_ex(const char *str, const char **endptr, int base) {
  return 0;
}

void str_from_integer(char *dest, size_t size, int n) {
}

void str_copy(char *dest, size_t size, const char *str) {
}

char *str_duplicate(const char *str) {
  return NULL;
}

void str_concat_string(char *dest, size_t size, const char *str) {
}

void str_concat_char(char *dest, size_t size, char c) {
}

void str_concat_integer(char *dest, size_t size, int n) {
}

void str_concat_array(char *dest, size_t size, const char *args[], char separator) {
}

char *str_join_string(const char *str1, const char *str2, char separator) {
  return NULL;
}

char *str_join_array(const char *args[], char separator) {
  return NULL;
}
