import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

public class Clavier {
	static BufferedReader flux = new BufferedReader(new InputStreamReader(System.in));

	public static byte lireByte(){
		byte b = 0;
		try{
			b = Byte.valueOf(flux.readLine()).byteValue();
		} catch(IOException e){System.out.println("Erreur de lecture");}
		return b;
	}

	public static short lireShort(){
		short s = 0;
		try{
			s = Short.valueOf(flux.readLine()).shortValue();
		} catch(IOException e){System.out.println("Erreur de lecture");}
		return s;
	}

	public static int lireInt(){
		int i = 0;
		try{
			i = Integer.valueOf(flux.readLine()).intValue();
		} catch(IOException e){System.out.println("Erreur de lecture");}
		return i;
	}

	public static long lireLong(){
		long l = 0;
		try{
			l = Long.valueOf(flux.readLine()).longValue();
		} catch(IOException e){System.out.println("Erreur de lecture");}
		return l;
	}

	public static double lireDouble(){
		double d = 0;
		try{
			d = Double.valueOf(flux.readLine()).doubleValue();
		} catch(IOException e){System.out.println("Erreur de lecture");}
		return d;
	}

	public static float lireFloat(){
		float f = 0;
		try{
			f = Float.valueOf(flux.readLine()).floatValue();
		} catch(IOException e){System.out.println("Erreur de lecture");}
		return f;
	}

    public static char lireChar(){
	char c = 0x00;
	try{
	    String s = flux.readLine();
	    if (s.length()>0)
		c = flux.readLine().charAt(0);
	} catch(IOException e){System.out.println("Erreur de lecture");}
	return c;
    }

	public static String lireString(){
		String s = "";
		try{
			s = flux.readLine();
		} catch(IOException e){System.out.println("Erreur de lecture");}
		return s;
	}

	
}
